export interface SkeletonProps {
  className?: string;
  count?: number;
}